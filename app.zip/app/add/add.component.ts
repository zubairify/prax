import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlbumModel } from '../album.model';
import { AlbumService } from '../services/album.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  album = new AlbumModel;
  genres : string[];

  constructor(private service : AlbumService, private router : Router) { 
    this.genres = ["Rock","Jazz","Pop","Rap","HipHop"];
  }

  ngOnInit(): void {
  }

  addAlbum() {
    // Calling service's saveAlbum function by passing album object
    this.service.saveAlbum(this.album);
    // Navigating to list component after saving album
    this.router.navigate(['list']);
  }
}
