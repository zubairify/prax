import { Injectable } from '@angular/core';
import { AlbumModel } from '../album.model';

@Injectable({
  providedIn: 'root'
})
export class AlbumService {
  albums : AlbumModel[] = [];

  constructor() { }

  saveAlbum(album : AlbumModel) {
    // Pushing album into array albums
    this.albums.push(album);
  }

  getAlbums() : AlbumModel[] {
    // Returing album arrays
    return this.albums;
  }
}
